<!DOCTYPE html>
<html lang="ru">

<head>
             <meta property='og:type' content='website'> <meta property='og:site_name' content='pristavkaa2.solarserenade.uno'> <meta property='og:image:type' content='image/png'> <meta property='og:image:width' content='968'> <meta property='og:image:height' content='504'> <meta property='og:image' content='//pristavkaa2.solarserenade.uno//og.png'> <meta property='og:locale' content='ru_RU'> <meta property='og:url' content='//pristavkaa2.solarserenade.uno/index.php'> <!-- Google tag (gtag.js) --> <script async src="https://www.googletagmanager.com/gtag/js?id=AW-16967595712"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'AW-16967595712'); </script>
<style>
		#order3 li img {
				max-width:150px;
				max-height: 150px;
				object-fit: cover;
		}
</style>


 


<meta charset="utf-8">
   <meta name="viewport" content="width=480">
   <title>Ігрова безпровідна приставка</title>
   <link rel="shortcut icon" href="images/favicon.png" type="image/png">
   <link rel="stylesheet" href="css/push.css">
   <link rel="stylesheet" href="css/ProximaStara.css">
   <link rel="stylesheet" type="text/css" href="css/Bratello.css">
   <link rel="stylesheet" href="css/fontss.css">
   <link rel="stylesheet" href="css/slicka.css">
   <link rel="stylesheet" href="css/options.css">
   <link rel="stylesheet" href="css/nastyle.css">
    <!-- new -->
    <link rel="stylesheet" href="css/swiper-bundle.min.css">
    
    <!-- end new -->
 
<style>
    #order3 li img {
        max-width:150px;
        max-height: 150px;
        object-fit: cover;
    }
</style>


<!-- add new 2 -->
 <link rel="stylesheet" href="css/all.min.css" type="text/css">

<style>

/* Моб меню */
.modal-body {
    background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
    z-index: 90;
    padding: 100px 0 0 0;
    display: inline-block;
    max-width: 480px;
    width: 100%;
    -webkit-transform: skewX( -5deg) translateX(200%);
    -ms-transform: skewX(-5deg) translateX(200%);
    transform: skewX( -5deg) translateX(200%);
    position: fixed;
    top: 0;
    right: 0;
    left: 0;
    margin: 0 auto;
    opacity: 0;
    will-change: transform, opacity;
    -webkit-transition: opacity 0.1s, -webkit-transform 0.3s;
    transition: opacity 0.1s, -webkit-transform 0.3s;
    -o-transition: transform 0.3s, opacity 0.1s;
    transition: transform 0.3s, opacity 0.1s;
    transition: transform 0.3s, opacity 0.1s, -webkit-transform 0.3s;
    height: 100vh;
    overflow: auto;
    }

.modal-block {padding: 0;}

.modal-block li {text-align: right;padding: 0 10px;border-bottom: 1px solid ;display: block;height: 47.5px; display: flex;flex-direction: row;justify-content: flex-end;align-content: center;align-items: center;}

.modal-block li a {text-decoration: none;font-weight: bold;text-transform: uppercase;color: #ffffff;display: block;width: 100%;height: 47.5px;line-height: 47.5px;}

.modal-body.show-menu {opacity: 1 !important;
    transform: skewX(0deg) translate(0, 0) !important;
    -webkit-transform: skewX( 0deg) translate(0, 0) !important;
    -ms-transform: skewX(0deg) translate(0, 0) !important;}

header {
    width: 100%;height: 80px;
    transform: translate(0, -100%);
    transition: 0.5s;
    padding: 0 20px;
    display: flex;
    align-content: center;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    max-width: 481px;
    margin: 0 auto;
}

header.active {
    position: fixed;
    left: 0;
    right: 0;
	top: 0;
    transform: translate(0, 0);
    transition: 0.5s;
    z-index: 100;
    box-shadow: 0px 4px 6px rgb(0 0 0 / 20%);
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

header a.logo svg {
    width: 100px;
    margin: 0 0;
    
}

header a.logo {
    width: 100px;
    height: 60px;
    transition: 0.6s;
    position: absolute;
    left: 190px;
}

header a.logo:hover {
    opacity: 0.7;
}

svg.nav-button {
    width: 45px;
    transition: 0.6s;
    cursor: pointer;
    position: absolute;
    left: 410px;
}

svg.nav-button:hover {opacity: 0.7;}

.show-li:nth-child(1) {
    -webkit-transition-delay: 0.1s !important;
    -o-transition-delay: 0.1s !important;
    transition-delay: 0.1s !important;
}
.show-li:nth-child(2) {
    -webkit-transition-delay: 0.2s !important;
    -o-transition-delay: 0.2s !important;
    transition-delay: 0.2s !important;
}
.show-li:nth-child(3) {
    -webkit-transition-delay: 0.3s !important;
    -o-transition-delay: 0.3s !important;
    transition-delay: 0.3s !important;
}
.show-li:nth-child(4) {
    -webkit-transition-delay: 0.4s !important;
    -o-transition-delay: 0.4s !important;
    transition-delay: 0.4s !important;
}
.show-li:nth-child(5) {
    -webkit-transition-delay: 0.5s !important;
    -o-transition-delay: 0.5s !important;
    transition-delay: 0.5s !important;
}
.show-li:nth-child(6) {
    -webkit-transition-delay: 0.6s !important;
    -o-transition-delay: 0.6s !important;
    transition-delay: 0.6s !important;
}

.modal-block li svg {width: 36px;fill: #fff;}

section.sect99 {
    padding: 40px 0 0 0;
}
.offer_section-top{border-top: 80px solid #4f41a2;}

.clearfix:after {
	content: "";
	display: block;
	clear: both;
}
img {
	max-width: 100%;
	height: auto;
}
b {
	font-weight: 700;
}

/* Моб меню */


/*  Блок  b1   */

.b1 {
 background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

.b1 h3 {
text-align: center;
    margin: 20px auto 0;
    font-size: 17px;
    text-transform: uppercase;
}

.b1 .alert {
    position: relative;
    
    color: #fff;
    font-size: 17px;
    text-align: justify;
    text-align-last: center;
    padding: 10px 8px 0;
    margin: 0px 20px 0;
}

.b1 .list-v1 {
 padding-bottom: 30px;
}
/*  Блок  b1   */
/* Блок  b2   */

.b2 {
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

.b2 {
 padding-top: 25;
}

.b2.pat:before {
 margin-bottom: 10px;
}

.b2 a.button {
 margin-top: 40px;
 
}

/*  Блок b2   */

/*  Блок b3   */

.b3 h2.title {
 margin-bottom: 15px;
}

.b3 .alert {
 position: relative;
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
 font-size: 19px;
 text-align: center;
 padding: 30px 10px 20px;
 margin: 20px 30px 0;
 -webkit-border-radius: 40px;
 -moz-border-radius: 40px;
 border-radius: 40px;
}

.b3 .alert:before {
 position: absolute;
 left: 50%;
 top: -23px;
 margin-left: -23px;
 display: block;
 width: 45px;
 height: 45px;
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
 content: '';
}

/*  Блок b3   */

/*  Блок b4   */

.b4 {
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

.b4 h2.title {
 margin-bottom: 20px;
}

.b4 .image {
 display: block;
 margin-bottom: 30px;
}

.b4 .char-list {
 padding-bottom: 25px;
}

.char-list li {
 padding: 8px 30px;
    color: #fff;
}

.char-list li:nth-child(even) {
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

.char-list li b {
 display: block;
 float: left;
 width: 150px;
}

.char-list li span {
 display: block;
 margin-left: 167px;
}

/*  Блок b4   */

/*   Про наш магазин  */

        .container {
            display: flex;
            align-items: center;
            
        }

        .photo {
            margin-right: 20px;
        }
        .small-font {
            font-size: 15px;
            margin-right: 20px;
        }
         .image-with-margin {
            margin-right: 20px;
            margin-left: 20px;
        }

/*   Про наш магазин  */

/*   Як замовити   */

.order-info h2.title {
 padding: 0 30px;
 background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

.order-list {
 padding: 0 30px;
}

.order-list li {
 position: relative;
 display: table;
 width: 100%;
 height: 160px;
 font-size: 20px;
 background: #fff;
 padding-left: 185px;
 margin-bottom: 20px;
 -webkit-box-shadow: 0 0 18px rgba(0, 0, 0, 0.21);
 -moz-box-shadow: 0 0 18px rgba(0, 0, 0, 0.21);
 box-shadow: 0 0 18px rgba(0, 0, 0, 0.21);
 -webkit-border-radius: 40px;
 -moz-border-radius: 40px;
 border-radius: 40px;
}

.order-list li:last-child {
 margin-bottom: 0;
}

.order-list .txt {
 display: table-cell;
 vertical-align: middle;
 padding-right: 20px;
}

.order-list li:before {
 position: absolute;
 top: 50%;
 left: 25px;
 margin-top: -68px;
 display: block;
 width: 135px;
 height: 135px;
 background-color: #000;
 background-repeat: no-repeat;
 background-position: 50% 50%;
 -webkit-border-radius: 50%;
 -moz-border-radius: 50%;
 border-radius: 50%;
 content: '';
}

/*   Як замовити   */

/*   Відгуки  */
.reviews_section {
    padding: 30px 20px;
   background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
   
   
}
.reviews_section h2 {
    margin: 0 0 30px;
    
}
.wtsp_item {
    max-width: 410px;
    min-height: 710px;
    margin: 0 auto;
    background: url("images/ADhTyuE4T3ar.jpg") 50% 0% repeat;
    font-family: Arial, Helvetica, sans-serif;
    position: relative;
    overflow: hidden;
    border-radius: 20px 20px 20px 20px;
    border: 2px solid #47BCC4;
    box-shadow: 1px 2px 20px 0px #47BCC4;
}
.wtsp_item .info {
    background: #ffffff url("images/XS6fbttaUIgm.png") 3px 50% no-repeat;
    padding: 16px 110px 13px 50px;
    box-shadow: 0 0 12px 0 rgba(0, 0, 0, 0.35);
    position: relative;
    z-index: 2;
    border-radius: 20px 20px 0px 0px;
    text-align: left;
}
.wtsp_item .info > img {
    float: left;
    border-radius: 50%;
    width: 42px;
    border: 1px solid #0f3a33;
    
}
.wtsp_item .info .text {
    overflow: hidden;
    padding-left: 8px;
    color: #333;
}
.wtsp_item .info .text > p {
    font-size: 16px;
    line-height: 22px;
    font-weight: 700;
}

.wtsp_item .info .text > small {
    font-size: 13px;
    line-height: 18px;
    display: block;
}

.clearfix:after {
    content: "";
    display: block;
    clear: both;
}
.wtsp_item .date {
    text-align: center;
    margin-top: 10px;
}
.wtsp_item .date > span {
    display: inline-block;
    vertical-align: top;
    background: #d4ebf3;
    text-transform: uppercase;
    font-size: 12px;
    line-height: 28px;
    color: #3f5250;
    padding: 0 8px;
    border-radius: 7px;
    box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.2);
}
.wtsp_item .message_container {
    margin-top: 10px;
    padding: 0 12px;
}
.wtsp_item .message {
    display: inline-block;
    max-width: 295px;
    min-width: 70px;
    padding: 6px 10px;
    position: relative;
    font-size: 18px;
    line-height: 22px;
    color: #212121;
    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.25);
    margin-bottom: 10px;
}
.wtsp_item .message.client {
    background: #fff;
    border-radius: 0 6px 6px 6px;
}
.wtsp_item .message.client:before {
    content: "";
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 0 8px 8px 0;
    border-color: transparent #fff transparent transparent;
    position: absolute;
    top: 0;
    left: -6px;
}
.wtsp_item .message > p {
    margin-bottom: 5px;
    text-align: left;
}
.wtsp_item .message > img {
    display: block;
    margin: 6px auto;
    border-radius: 4px;
}
.wtsp_item .message .time {
    text-align: right;
    font-size: 14px;
    line-height: 15px;
    color: #989898;
    padding: 0 5px;
}
.wtsp_item .message:last-child {
    margin-bottom: 0;
}
.wtsp_item .message.author {
    background: #c8e2fd;
    border-radius: 10px 0 10px 10px;
    padding: 6px 10px;
    float: right;
}
.wtsp_item .message.author:before {
    content: "";
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 8px 8px 0 0;
    border-color: #c8e2fd transparent transparent transparent;
    position: absolute;
    top: 0;
    right: -6px;
}
.wtsp_item .message.author .time {
    padding: 0;
}
.wtsp_item .message.author .time:after {
    content: "";
    width: 18px;
    height: 12px;
    background: url("urn:scrapbook:download:error:https://susharka2.shopplite.com/reviews__wtsp_read.html") 50% 50% no-repeat;
    display: inline-block;
    vertical-align: middle;
    margin: -2px 0 0 4px;
}
.wtsp_item:after {
    content: "";
    width: 404px;
    height: 57px;
    background: url("images/LKvurt5AgpH6.png") 50% 50% no-repeat;
    position: absolute;
    left: 50%;
    margin-left: -202px;
    bottom: 7px;
}
.owl-carousel .owl-stage-outer {
    position: relative;
    overflow: hidden;
    -webkit-transform: translate3d(0,0,0);
}
.no-js .owl-carousel, .owl-carousel.owl-loaded {
    display: block;
	position: relative;
}
.owl-carousel .owl-item{
    min-height: 1px;
    float: left;
    -webkit-backface-visibility: hidden;
    -webkit-touch-callout: none;
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;
    -ms-backface-visibility: hidden;
    -webkit-transform: translate3d(0,0,0);
    -moz-transform: translate3d(0,0,0);
    -ms-transform: translate3d(0,0,0);
    -webkit-tap-highlight-color: transparent;
    position: relative;
}
.wtsp_rev .owl-prev, .wtsp_rev .owl-next {
    width: 47px;
    height: 47px;
    background: #000000 url("images/g9nXtD5LDSge.jpg") no-repeat;
    position: absolute;
    top: 50%;
    margin-top: -23px;
}
.wtsp_rev .owl-prev {
    background-position: left center;
    -webkit-border-radius: 0 6px 6px 0;
    -moz-border-radius: 0 6px 6px 0;
    border-radius: 0 6px 6px 0;
    left: -20px;
}
.owl-carousel .owl-dot, .owl-carousel .owl-nav .owl-next, .owl-carousel .owl-nav .owl-prev {
    cursor: pointer;
    cursor: hand;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}


.owl-carousel .owl-dot, .owl-carousel .owl-nav .owl-next, .owl-carousel .owl-nav .owl-prev {
    cursor: pointer;
    cursor: hand;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}
.wtsp_rev .owl-next {
    background-position: right center;
    -webkit-border-radius: 6px 0 0 6px;
    -moz-border-radius: 6px 0 0 6px;
    border-radius: 6px 0 0 6px;
    right: -20px;
}
/*   Відгуки  */

/*   Рамка для фото   */
.img-text {
    display: block;
    width: 90%;
    margin: 0 auto 15px;
    padding: 2%;
    border: 2px solid #47BCC4;
    border-radius: 15px;
    box-shadow: 1px 2px 20px 0px #47BCC4;
}
/*   Рамка для фото  */

/*   Бігуща строка  */

        @keyframes marqueeAnimation {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }

        .marquee-container {
            overflow: hidden;
        }

        .marquee-text {
            animation: marqueeAnimation 10s linear infinite;
            white-space: nowrap;
            font-size: 16px;
        }

        /* Адаптация для мобильных устройств */
        @media (max-width: 480px) {
            .marquee-text {
                font-size: 12px;
                animation-duration: 10s; /* Уменьшим длительность анимации для более быстрой прокрутки */
            }
        }

/*   Бігуща строка  */

/*   Головні стилі  */

.button {
	display: block;
	margin: 0 auto;
	max-width: 400px;
	height: 83px;
	width: 100%;
	border: none;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
background-image: radial-gradient(circle at 50% 50%, #47d6d9 0, #47c9cf 25%, #47bcc4 50%, #48afb9 75%, #48a2ae 100%);	font-family: 'Roboto', sans-serif;
	font-weight: 400;
	font-size: 20px;
	line-height: 80px;
	letter-spacing: 2px;
	color: #fff;
	text-transform: uppercase;
	text-decoration: none;
	text-align: center;
	cursor: pointer;
	border: 2px solid #47BCC4;
    box-shadow: 1px 2px 20px 0px #47BCC4;
}

.pat {
 position: relative;
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

.offer_section.offer3 .benefits_list {
	padding: 12px 0 12px 18px;
	background: #4f41a2;
    background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
	color: #3a3d45;
	color: #333;
	display: flex;
	flex-direction: row;
	align-content: center;
	justify-content: space-around;
	align-items: center;
	border-radius: 20px 20px 20px 20px;
    border: 2px solid #47BCC4;
    box-shadow: 1px 2px 20px 0px #47BCC4;
}

.slick-dots {
 height: 23px;
 text-align: center;
 margin-top: 25px;
}

.slick-dots:after {
 clear: both;
 content: "";
 display: block;
 height: 0;
 width: 0;
 visibility: hidden;
}

.slick-dots li {
 display: inline-block;
 vertical-align: top;
 padding: 0 6px;
 overflow: hidden;
}

.offer {
 padding: 0;
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
}

.offer .box {
 position: relative;
background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
 height: 600px;
}

.offer .main-title {
 font-family: 'Acrom', Arial, Helvetica, sans-serif;
 font-size: 44px;
 font-weight: 700;
 line-height: 50px;
 color: #fff;
 text-align: center;
 text-transform: uppercase;
 padding: 10px 0 3px;
}

.offer .sub-title {
 font-size: 25px;
 color: #fff;
 text-align: center;
 padding-bottom: 15px;
}

.offer .sale {
background: url("") 0 0 no-repeat;
    width: 209px;
    height: 113px;
    margin-left: 267px;
    color: #fff;
    font-size: 26px;
    line-height: 40px;
    text-align: center;
    margin-top: 143px;
    position: absolute;
}

.offer .sale span {
 display: inline-block;
 transform: rotate(-7deg);
 padding-top: 9px;
}

.offer .sale b {
 display: block;
 font-size: 50px;
}

.offer .bullet {
 font-size: 0;
 padding: 0 10px 20px;
}

.offer .bullet li {
 display: inline-block;
 vertical-align: top;
 width: 33.33%;
 font-size: 18px;
 text-align: center;
}

.offer .bullet .pic {
 position: relative;
 margin-bottom: 15px;
}

.offer .bullet .pic:after {
 position: absolute;
 left: 50%;
 bottom: -9px;
 margin-left: -15px;
 display: block;
 width: 30px;
 height: 30px;
 background: url("") 0 0 no-repeat;
 content: '';
}

.offer .bullet img {
 display: block;
 margin: 0 auto;
 border: 4px solid #fff;
 -webkit-border-radius: 4px;
 -moz-border-radius: 4px;
 border-radius: 4px;
}

.offer .bullet p {
 padding: 0 5px;
    color: #f5f5f5;
}


.offer.bottom .price {
 position: relative;
 margin-bottom: -55px;
 z-index: 5;
}

.offer.bottom .timer {
 margin-top: 30px;
}

.order_form .form-txt {
 color: #000000;
 text-align: center;
 padding-bottom: 20px;
}

.order_form .pat {
 color: #fff;

}

.order_form .form-txt h4 {
 font-size: 30px;
 padding-bottom: 7px;
 text-transform: uppercase;
 color: #fff;
 
}

.order_form .form-txt p {
 font-size: 18px;
 padding: 0 75px;
 color: #fff;
}

.benef2{
    padding: 0 30px 30px;
}
.benef2>li{
	display: table;
	width: 100%;
	margin-bottom: 32px;
	position: relative;
}
.benef2>li:not(:last-child):after{
	content: '';
	width: 180px;
	height: 3px;
	background: url("") 0% 50% repeat;
	transform: rotate(30deg);
	position: absolute;
	bottom: -20px;
	left: 120px;
	z-index: 1;
}
.benef2>li:nth-child(2n):after{
	transform: rotate(-30deg);
	position: absolute;
	bottom: -20px;
	right: 120px;
}
.benef2>li:last-child{
	margin-bottom: 0;
}
.benef2>li .img{
	width: 166px;
	display: table-cell;
	vertical-align: middle;
}
.benef2>li .img>img{
	display: block;
	margin: 0 auto;
	border-radius: 50%;
	box-shadow: 0 0 30px 0 rgba(0,0,0,0.3);
	position: relative;
	z-index: 2;
}
.benef2>li>p{
	display: table-cell;
	vertical-align: middle;
	padding: 0 0 0 26px;
}
.benef2>li>p>span{
	display: block;
	font-weight: 700;
	font-size: 24px;
	line-height: 1.2em;
}
.benef2>li:nth-child(2n)>p{
	padding: 0 26px 0 0;
	text-align: right;
}

.bottom .order_form{
	    padding-top: 80px;
}

.offer_text {
    font-size: 13px;
    line-height: 27px;
    text-transform: uppercase;
    font-weight: 600;
    position: relative;
    letter-spacing: -0.1px;
    margin-left: 10px;
    height: 25px;
    top: -101px;
    color: #393d46;
    margin: 0 auto;
    text-align: center;
    background: #fbb83b;
}

.offer_text>span {
    padding-left: 12px;
    padding-right: 12px;
}

.offer_section.offer3 .benefits_list {
	padding: 12px 0 12px 18px;
	background: #4f41a2;
    background-image: radial-gradient(circle at 50% 50%, #363c3b 0, #303232 16.67%, #272325 33.33%, #1a0e15 50%, #080000 66.67%, #000000 83.33%, #000000 100%);
	color: #3a3d45;
	color: #333;
	display: flex;
	flex-direction: row;
	align-content: center;
	justify-content: space-around;
	align-items: center;
}

.offer_section.offer3 .benefits_list .benefit_item {
	float: left;
	padding: 0 0 0 44px;
	width: 31%;
	font-size: 12px;
	line-height: 16px;
	position: relative;
	color:#fff;
}

.offer_section.offer3 .benefits_list .benefit_item:before {
	display: block;
	content: '';
	width: 34px;
	height: 34px;
	border: 1px solid rgba(255, 255, 255, 0.2);
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	border-radius: 50%;
	background: rgba(0, 0, 0, 0.1) center no-repeat;
	position: absolute;
	top: -2px;
	left: 0;
	
}

.offer_section.offer3 .price_block {
	display: flex;
}

.offer_section.offer3 .price_item {
	float: left;
	padding: 20px 0 0;
	width: 50%;
	height: 90px;
	/* border-right: 1px solid #e6e6e6; */
	text-align: center;
}

.offer_section.offer3 .price_item:last-child {
	border: none;
}

.offer_section.offer3 .price_item .text {
	margin: 0 0 5px;
	font-size: 14px;
	line-height: 14px;
	color:#fff;
}

.offer_section.offer3 .price_item.new .text {
	margin: 0 0 8px;
}

.offer_section.offer3 .price_item.new .text span {
	padding: 2px 5px 3px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
  background: #47BCC4;
  color: #fff;
  
}

.offer_section.offer3 .price_item.old .value {
	font-weight: 700;
	font-size: 30px;
	line-height: 30px;
	text-decoration: line-through;
	color:#fff;
}

.offer_section.offer3 .price_item.new .value {
	font-weight: 700;
	font-size: 36px;
	line-height: 36px;
	color:#fff;
}

.products_count {
	margin: 20px 0 0;
	text-align: center;
    color: #fff;
}

.offer_section.offer1 .products_count {
	color: #fff;
}

.products_count b {
	margin: 0 3px;
	padding: 3px 5px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	border-radius: 4px;
	background: #fff;
	color: #000;
}

/*   Головні стилі  */

.text-block {
            margin-bottom: 10px; /* Додавання відступу між стопчиками */
        }


</style>
</head>
<body>
                                                  

<div class="wrap">
   <style>
   .colortext {
     color: white; /* Красный цвет выделения */
   }
  </style>
<div class="offer_section offer3 ">
   
    <div class="timer_block clearfix">
                <p></p>
                <div class="timer clearfix">
                    <div class="timer_item">
                    
                    </div>
                </div>
            </div>
  <div style="    height: 100%;
    /* background: url(https://www.ironflex.co.ua/image/cache/catalog/banners/baner-header/baner-header-640x40-mobile-shaker-ua-640x40.jpg); */
    background-size: 100% 100%;
    color: #3c4152;
    text-align: center;
    font-size: 16px;
    padding-top: 2px;
    font-weight: 900;">

    <div class="marquee-container">
        <div class="marquee-text">
             ВСТИГНІТЬ ЗАМОВИТИ ДО ПІДВИЩЕННЯ ЦІН, ЗАМОВЛЯЙТЕ ВЖЕ СЬОГОДНІ ПО ЗНИЖЦІ
       </div>
    </div>

        </div>
<section class="offer">
            <div class="gallery">
               <div class="swiper-wrapper">
                   <div class="swiper-slide"><img src="images/1_1.jpg" alt=""></div>
              </div>
            </div>
            <div class="benefits_list clearfix">
                <div class="benefit_item">Доставка по Україні</div>
                <div class="benefit_item">Обмежена пропозиція</div>
                <div class="benefit_item">Оплата при отриманні</div>
            </div>
           
            <div class="price_block clearfix">
                <div class="price_item old">
                    <div class="text">Звичайна ціна:</div>
                    <div class="value">1998 грн</div>
                </div>
                <div class="price_item new">
                    <div class="text"><span>Ви заощаджуєте -50%</span></div>
                    <div class="value">999 грн</div>
                </div>
            </div> 
            
         <ul>
            <li>Потужний процесор нового покоління;</li>
            <li>В комплекті 20 000 ігор;</li>
            <li>2 зручних безпровідних геймпади;</li>
         </ul>
           
            <div class="btn-block">
                <a href="#order6" class="button">Придбати по знижці</a>
            </div>
            <div class="products_count">* Залишилось <b>17</b> шт по знижці</div>
      </section></div>


<section class="b1">
     <h2 id="order1" class="title gold">ВІДЕО ОГЛЯД<span>ПРИСТАВКИ</span></h2>
     <div class="video-block">
         <video class="img-text" width="100%" height="100%" loop="" autoplay="" muted="" playsinline=""><source src="media/1.mp4" type="video/mp4"></video>
      </div>
      
</section>

<section class="b1">
      <div id="order2" class="alert"><p><b>Безпровідна ігрова приставка</b> - це занурення в світ безмежних можливостей геймінгу до нових вражень та емоцій у світі віртуальних пригод.</p></div>
</section>

<section class="b1">
      <div class="slider-photo">
         <div class="item">
            <img class="img-text" src="images/2.webp">
         </div>
      </div>
</section>

<section class="b1">
      <div id="order2" class="alert"><p>Завдяки цьому потужному процесору і відмінній оптимізації, ви можете насолоджуватися іграми без будь-яких затримок у геймплеї.</p>
</div></section>

<section class="b1">
      <div class="slider-photo">
         <div class="item">
            <img class="img-text" src="images/3.webp">
         </div>
      </div>
</section>

<section class="b1">
      <div id="order2" class="alert"><p>Ці геймпади відрізняються відмінною ергономікою, що дозволяє комфортно тримати їх у руках протягом тривалих ігрових сесій.</p></div>
</section>

<section class="b1">
      <div class="slider-photo">
         <div class="item">
            <img class="img-text" src="images/4.webp">
         </div>
      </div>
</section>

<section class="b1">
      <div id="order2" class="alert"><p>В комплекті з цією приставкою ви отримуєте доступ до неймовірної колекції, яка налічує 20 000 ігор.</p></div>
</section>

<section class="b1">
      <div class="slider-photo">
         <div class="item">
            <img class="img-text" src="images/5.webp">
         </div>
      </div>
</section>

<section class="b1">
<div id="order2" class="alert"><p>Завдяки своїм компактним розмірам, нашу бездротову ігрову приставку легко взяти з собою куди завгодно</p></div>
</section>


<section id="order3" class="b2 pat">
      <h2 class="title white"><span>Переваги</span>ПРИСТАВКИ</h2>
      <ul class="list-v2">
          <li>
            <div class="text">
              <p><b>Компактні розміри!</b></p>
              <p>Завдяки своїм компактним розмірам ви можете легко взяти цю приставку з собою куди завгодно.</p>
            </div>
            <img src="images/6.webp">
          </li>
         <li>
            <div class="text">
               <p><b>Бездротове з'єднання!</b></p>
              <p>Забудьте про обмеження проводів, адже приставка працює за допомогою бездротового з'єднання.</p>
            </div>
            <img src="images/7.webp">
          </li>
         <li>
            <div class="text">
              <p><b>Велика бібліотека ігор!</b></p>
              <p>Приставка налічує 20 000 ігор в комплекті, тому ви завжди знайдете щось, що вас зацікавить.</p>
            </div>
            <img src="images/8.webp">
          </li>
      </ul>
      <br>
      <div class="btn-block">
                <a href="#order6" class="button">Придбати по знижці</a>
      </div>
 <br>
 <br>

    <div class="container">
        <img class="image-with-margin" src="" alt="">
        <p class="small-font">Магазин OnlineBliss - це ваша гарантія безпеки і надійності. Остерігайтеся шахраїв, які копіюють наші магазини і продають не якісну продукцію.
    </p></div>

</section>

<section id="order4" class="b4 pat">
      <h2 class="title white"><span>Характеристики</span>ПРИСТАВКИ</h2>
      <img class="img-text" src="images/9.webp">
     <ul class="char-list">
         <li><b>Колір:</b> <span>Чорний;</span></li>
         <li><b>Процесор:</b> <span>Game Stick;</span></li>
         <li><b>К-сть ігор:</b> <span>20 000 ігор;</span></li>
         <li><b>Інтерфейс:</b> <span>HDMI;</span></li>
         <li><b>Живлення:</b> <span>USB,2 батарейки AAA;</span></li>
         <li><b>Оперативна пам'ять:</b> <span>256 мб;</span><br></li>
         <li><b>Вбудована пам'ять:</b> <span>64 гб;</span><br></li>
         <li><b>Комплект:</b> <span>- Ігрова консоль;<br>- 2 геймпади;<br>- USB WI-FI адаптер;<br>- HDMI перехідник;<br>- Кабель Micro-USB;<br>- Упаковка;<br></span></li>
      </ul>
<a href="#order6" class="button">Придбати по знижці</a>
</section>


<section id="order5" class="reviews_section">
       <h2 class="title"><span>ВІДГУКИ</span>НАШИХ ПОКУПЦІВ</h2>
      <div class="wtsp_rev owl-carousel owl-loaded">
        
       
      <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-880px, 0px, 0px); transition: all 0s ease 0s; width: 3520px;"><div class="owl-item cloned" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava3.webp" alt="">
            <div class="text">
              <p>Щур Ігор</p>
              <small>був(-ла) сьогодні о 09:13</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message client">
              <p>
               Придбавши цю приставку для своїх дітей, я був приємно вражений її функціональністю та легкістю використання. Діти в захваті від великої кількості ігор.
              </p>
              <img src="images/11.webp" alt="">
              <div class="time">16:45</div>
            </div>
            <div class="message author">
              <p>
                Доброго дня, Ігор! Дякуємо Вам за відгук. Замовляйте ще😍
              </p>
              <div class="time">16:47</div>
            </div>
          </div>
        </div></div><div class="owl-item cloned" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava1.webp" alt="">
            <div class="text">
              <p>Казанчук Світлана</p>
              <small>був(-ла) сьогодні о 10:45</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message author">
              <p>
                Доброго дня! Ви залишали заявку в нашому інтернет-магазині. Не
                могли б ви написати відгук про товар нам буде дуже приємно))
              </p>
              <div class="time">18:24</div>
            </div>
            <div class="message client">
              <p>Я купила цю приставку своїм дітям, і вони були в захваті! Вони не можуть втриматися від гри, а я бачу, як вони весело проводять час з друзями.</p>
              <div class="time">19:30</div>
            </div>
            <div class="message author">
              <p>Ми раді, що вам все сподобалося! Дякую за відгук))</p>
              <div class="time">19:35</div>
            </div>
          </div>
        </div></div><div class="owl-item active" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava2.webp" alt="">
            <div class="text">
              <p>Власик Ольга</p>
              <small>був(-ла) вчора о 19:14</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message client">
              <p>
                Мої діти зовсім зачаровані цією приставкою! Вони захопливо проводять час, граючи у свої улюблені ігри. Рекомендую!            </p>
              <img src="images/10.webp" alt="">
              <div class="time">17:01</div>
            </div>
            <div class="message author">
              <p>
                Добрий вечір, Ольга! Ми дуже раді, що Ви залишилися задоволені! Дякуємо за відгук😍
              </p>
              <div class="time">17:12</div>
            </div>
          </div>
        </div></div><div class="owl-item" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava4.webp" alt="">
            <div class="text">
              <p>Шишло Олександр</p>
              <small>був(-ла) сьогодні о 09:12</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message author">
              <p>
                Олександр, доброго дня! Ви залишали заявку в нашому інтернет-магазині. Не
                могли б ви написати невеликий відгук про товар?
              </p>
              <div class="time">14:25</div>
            </div>
            <div class="message client">
              <p>
                Ця бездротова ігрова приставка просто космос! Графіка дивовижна, геймплей плавний, абсолютно ніяких затримок. Я із задоволенням граю в улюблені ігри.
              </p>

              <div class="time">15:47</div>
            </div>
            <div class="message author">
              <p>Ми раді, що Вам все сподобалося! Дякую за відгук)</p>
              <div class="time">15:53</div>
            </div>
          </div>
        </div></div><div class="owl-item" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava3.webp" alt="">
            <div class="text">
              <p>Щур Ігор</p>
              <small>був(-ла) сьогодні о 09:13</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message client">
              <p>
               Придбавши цю приставку для своїх дітей, я був приємно вражений її функціональністю та легкістю використання. Діти в захваті від великої кількості ігор.
              </p>
              <img src="images/11.webp" alt="">
              <div class="time">16:45</div>
            </div>
            <div class="message author">
              <p>
                Доброго дня, Ігор! Дякуємо Вам за відгук. Замовляйте ще😍
              </p>
              <div class="time">16:47</div>
            </div>
          </div>
        </div></div><div class="owl-item" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava1.webp" alt="">
            <div class="text">
              <p>Казанчук Світлана</p>
              <small>був(-ла) сьогодні о 10:45</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message author">
              <p>
                Доброго дня! Ви залишали заявку в нашому інтернет-магазині. Не
                могли б ви написати відгук про товар нам буде дуже приємно))
              </p>
              <div class="time">18:24</div>
            </div>
            <div class="message client">
              <p>Я купила цю приставку своїм дітям, і вони були в захваті! Вони не можуть втриматися від гри, а я бачу, як вони весело проводять час з друзями.</p>
              <div class="time">19:30</div>
            </div>
            <div class="message author">
              <p>Ми раді, що вам все сподобалося! Дякую за відгук))</p>
              <div class="time">19:35</div>
            </div>
          </div>
        </div></div><div class="owl-item cloned" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava2.webp" alt="">
            <div class="text">
              <p>Власик Ольга</p>
              <small>був(-ла) вчора о 19:14</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message client">
              <p>
                Мої діти зовсім зачаровані цією приставкою! Вони захопливо проводять час, граючи у свої улюблені ігри. Рекомендую!            </p>
              <img src="images/10.webp" alt="">
              <div class="time">17:01</div>
            </div>
            <div class="message author">
              <p>
                Добрий вечір, Ольга! Ми дуже раді, що Ви залишилися задоволені! Дякуємо за відгук😍
              </p>
              <div class="time">17:12</div>
            </div>
          </div>
        </div></div><div class="owl-item cloned" style="width: 440px;"><div class="wtsp_item">
          <div class="info clearfix">
            <img src="images/ava4.webp" alt="">
            <div class="text">
              <p>Шишло Олександр</p>
              <small>був(-ла) сьогодні о 09:12</small>
            </div>
          </div>
          <div class="date">
            <span>Вчора</span>
          </div>
          <div class="message_container clearfix">
            <div class="message author">
              <p>
                Олександр, доброго дня! Ви залишали заявку в нашому інтернет-магазині. Не
                могли б ви написати невеликий відгук про товар?
              </p>
              <div class="time">14:25</div>
            </div>
            <div class="message client">
              <p>
                Ця бездротова ігрова приставка просто космос! Графіка дивовижна, геймплей плавний, абсолютно ніяких затримок. Я із задоволенням граю в улюблені ігри.
              </p>

              <div class="time">15:47</div>
            </div>
            <div class="message author">
              <p>Ми раді, що Вам все сподобалося! Дякую за відгук)</p>
              <div class="time">15:53</div>
            </div>
          </div>
        </div></div></div></div><div class="owl-nav"><div class="owl-prev"></div><div class="owl-next"></div></div><div class="owl-dots disabled"></div></div>
    </section>
  
    
    <section class="b1">
      <h2 class="title"><span>Як замовити</span>ПРИСТАВКУ?</h2>
      <ul class="order-list">
         <li>
            <div class="txt">
               <h4>Крок 1:</h4>
               <p>Заповніть форму замовлення</p>
            </div>
         </li>
         <li>
           <div class="txt">
              <h4>Крок 2:</h4>
              <p>Дочекайтесь дзвінка оператора</p>
           </div>
         </li>
         <li>
            <div class="txt">
               <h4>Крок 3:</h4>
               <p>Оплатіть товар після отримання</p>
            </div>
         </li>
      </ul>
   </section>
   
<div class="offer_section offer3 ">
   
   <div class="timer_block clearfix">
                <p></p>
                <div class="timer clearfix">
                    <div class="timer_item">
                       
                    </div>
                </div>
     </div>
     
  <div style="    height: 100%;
    /* background: url(https://www.ironflex.co.ua/image/cache/catalog/banners/baner-header/baner-header-640x40-mobile-shaker-ua-640x40.jpg); */
    background-size: 100% 100%;
    color: #3c4152;
    text-align: center;
    font-size: 16px;
    padding-top: 2px;
    font-weight: 900;">

    <div class="marquee-container">
        <div class="marquee-text">
             ВСТИГНІТЬ ЗАМОВИТИ ДО ПІДВИЩЕННЯ ЦІН, ЗАМОВЛЯЙТЕ ВЖЕ СЬОГОДНІ ПО ЗНИЖЦІ
       </div>
    </div>

        </div>
<section class="offer">
            <div class="gallery">
               <div class="swiper-wrapper">
                   <div class="swiper-slide"><img src="images/1_1.jpg" alt=""></div>
              </div>
            </div>
            <div class="benefits_list clearfix">
                <div class="benefit_item">Доставка по Україні</div>
                <div class="benefit_item">Обмежена пропозиція</div>
                <div class="benefit_item">Оплата при отриманні</div>
            </div>
           
             <div class="price_block clearfix">
                <div class="price_item old">
                    <div class="text">Звичайна ціна:</div>
                    <div class="value">1998 грн</div>
                </div>
                <div class="price_item new">
                    <div class="text"><span>Ви заощаджуєте -50%</span></div>
                    <div class="value">999 грн</div>
                </div>
            </div> 
            
 <div style="text-align: center; margin: 10px auto; display: block; font-size: 24px; line-height: 26px;"><strong>Залишіть заявку</strong><p>та отримайте консультацію</p></div>
 
<form id="order6" class="order_form" name="order-form" action="thankyou.php" method="post" onsubmit="if(this.name.value==''){alert('Введіть Ваше імя!');return false}if(this.phone.value==''){alert('Введіть Ваш номер телефону!');return false}return true;">
 
    <input class="field" type="text" name="name" placeholder="Введіть Ваше ім'я" required="" value="">
    <input class="field" type="tel" name="phone" placeholder="Введіть Ваш телефон" required="" value="">
 
    <button type="submit" class="button">Замовити зараз</button>
    <div class="products_count">* Залишилось <b>17</b> шт по знижці</div>
</form>

<footer>
    <div style="text-align: center; margin: 10px auto; display: block; font-size: 14px; line-height: 26px;">
            <div>
                         <p style="text-align: center;"> 
                    ТОВ «Шопінг»<br>
 Україна, 65031, Одеська обл., місто Одеса, вул.Грушевського Михайла, будинок 39Е, офіс 505
</p>
               
           <br>     
       <div style="color: white;">

                                        <p><a href="politics.html" style="text-decoration: none;color: white;" target="_blank">Політика конфіденційності</a></p>
                                        <p><a href="oferta.html" style="text-decoration: none;color: white;" target="_blank">Договір оферти</a></p>
                                        <p><a href="usersagitment.html" style="text-decoration: none;color: white;" target="_blank">Угода користувача</a></p>
                                        <p><a href="conditions.html" style="text-decoration: none;color: white;" target="_blank">Умови гарантії та повернення</a></p>
                                    </div>
            </div></div>
</footer>
</section>



    


</div></div>
<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/maskedinput.js"></script>
 <script> (function(){ for (var i = 0, forms = document.forms; i < forms.length; i++) { (function(form){ form.addEventListener('submit', function() { var tzoffset = (new Date()).getTimezoneOffset() * 60000; var localISOTime = (new Date(Date.now() - tzoffset)).toISOString(); var splitted = localISOTime.split('T'); var localTime = splitted[0] + ' ' + splitted[1].substr(0, 8); var fields = [ '<input type="hidden" name="_time" value="' + localTime + '">', '<input type="hidden" name="_utm_medium" value="">', '<input type="hidden" name="_utm_source" value="">', '<input type="hidden" name="_utm_campaign" value="">', '<input type="hidden" name="_utm_term" value="">', '<input type="hidden" name="_utm_content" value="">', ]; form.insertAdjacentHTML('beforeend', fields.join('')); return true; }) })(forms[i]); } })(); </script> <script> setTimeout(function(){ fbq('track', 'ViewContent'); },10000) </script></body></html>